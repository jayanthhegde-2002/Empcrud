package com.ems.main.dto;

import java.util.Date;

import com.ems.main.model.Employee;

public class EmployeeDTO {
	private Long id;
    private String name;
    private String emailId;
    private Date dob;
    private int age;
    private Double salary;
    private Boolean status;
	
	public EmployeeDTO() {		
	}
	
	public EmployeeDTO(Employee employee) {
		this.name = employee.getName();
		this.id = employee.getId();
		this.emailId= employee.getEmailId();
		
		this.dob = employee.getDob();
		this.age = employee.getAge();
		
		this.salary = employee.getSalary();
		this.status = employee.getStatus();
		
	}
	
	public EmployeeDTO(String firstName, String lastName) {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	
}
