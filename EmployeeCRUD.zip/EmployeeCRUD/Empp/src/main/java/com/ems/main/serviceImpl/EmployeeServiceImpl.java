package com.ems.main.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.main.dto.EmployeeDTO;
import com.ems.main.model.Employee;
import com.ems.main.repository.EmployeeRepository;
import com.ems.main.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepository;

	public void createOrUpdateEmployee(EmployeeDTO empDto) {
		Employee emp = convertDtoToModel(empDto);
		employeeRepository.save(emp);
	}
	
	public List<EmployeeDTO> getAllEmployee() {
		List<Employee> list = employeeRepository.findAll();
		List<EmployeeDTO> employeeList = list.stream()
	            .map(EmployeeDTO::new)
	            .collect(Collectors.toCollection(ArrayList::new));
		return employeeList;
	}
	
	public void deleteEmployee(Long id) {
		employeeRepository.deleteById(id);
	}
	
	public EmployeeDTO editEmployee(Long id) {
		Employee emp = employeeRepository.getOne(id);
		return convertModelToDTO(emp);
	}
	
	private Employee convertDtoToModel(EmployeeDTO empDto) {
		Employee emp = new Employee();
		if (empDto.getId() != null) {
			emp.setId(empDto.getId());
		}
	
		emp.setName(empDto.getName());
		emp.setEmailId(empDto.getEmailId());
		emp.setSalary(empDto.getSalary());
		emp.setDob(empDto.getDob());
		emp.setAge(empDto.getAge());
		emp.setStatus(empDto.getStatus());
	
		return emp;
	}
	
	private EmployeeDTO convertModelToDTO(Employee emp) {
		EmployeeDTO empDTO = new EmployeeDTO();
		empDTO.setId(emp.getId());
		empDTO.setAge(emp.getAge());
		
		empDTO.setEmailId(emp.getEmailId());
		empDTO.setName(emp.getName());
		empDTO.setSalary(emp.getSalary());
		empDTO.setDob(emp.getDob());
		
		empDTO.setStatus(emp.getStatus());

		return empDTO;
	}
}
